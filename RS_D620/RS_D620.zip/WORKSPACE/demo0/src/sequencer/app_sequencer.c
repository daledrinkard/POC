/*
            SEQUENCER app
*/
#include "application_common.h"
#include "cpan.h"
#include "app_sequencer.h"
#include "hal_data.h"
#include "power_module.h"
#include "r_gpt.h"
#include "r_ioport.h"       // IWYU pragma: keep
#include "POP/pop.h"
#include "simulator.h"
#include "comm_bus.h"
#include "dbg_print.h"  // IWYU pragma: keep
extern bsp_leds_t g_bsp_leds;
extern cpan_t *CP;
extern const power_rail_cfg_t power_analog_3300;
extern const power_rail_cfg_t power_analog_5000;
extern const power_rail_cfg_t power_analog_1200;
extern const power_rail_cfg_t power_digital_2400;
extern const power_rail_cfg_t power_digital_OFFLINE;
extern const power_controller_cfg_t power_controller_basic;
extern const power_rail_map_t power_rail_maps[PWR_MAX_RAILS];
//extern const power_rail_t power_rail_initial;
const cpan_t control_panel_initial = { 
        .stat = 0,
        .regs = {0},
             /* USER */
        .leds = &g_bsp_leds,  /* add the led structure */
        .p_SW1 = &g_SW1, /* add the SW1 external interrupt */
        .led_state = 0,
        .port_base =   {R_PORT1}, //@@@
        .port_shadow = {0},
        .port_enable = {0},
        .adc_value =   {0}
};

power_rail_cfg_t         rail_cfg_scratch[PWR_MAX_RAILS];
power_rail_ctrl_t        rail_ctrl_scratch[PWR_MAX_RAILS];
power_controller_ctrl_t  controller_ctrl_scratch;
extern const power_rail_t power_rails[PWR_MAX_RAILS];
power_controller_cfg_t controller_cfg_scratch;
extern const power_sequencer_CONST_t power_sequencer_CONST;

const power_controller_t PowerController = {    
    .rails =     (power_rail_t*)              &power_rails[0], 
    .cfg =       (power_controller_cfg_t *)   &controller_cfg_scratch,
    .cfg_store = (power_controller_cfg_t *)   DF_SEQUENCER_CONFIG_ADDR,
    .ctrl =      (power_controller_ctrl_t *)  &controller_ctrl_scratch,
//@    .map =       (power_rail_map_t *)         DF_POWER_RAIL_PINMAP_ADDR,
   /*
        The following are const in Flash
   */
    .GPIO =      (power_sequencer_IO_t *)     &power_sequencer_IO,
    .CONSTANTS = (power_sequencer_CONST_t *)  &power_sequencer_CONST
};
void app_sequencer_comm_cb(comm_event_t event, void *ctx);
int app_func_reset   (void)
{
   power_rail_t *p_rail;// = PowerController.rails;
    APP_INFO_PRINT("\nSEQUENCER RESET\n");
    POP0();


    #if 1 // only do this once, on first run, if the addresses of the dataflash segments change.
    APP_INFO_PRINT("\n ******* \n      UPDATING DATAFLASH  \n ***** \n");
     pwr_rail_store_config(0,(uint8_t*) &power_analog_3300,sizeof(power_rail_cfg_t));
     pwr_rail_store_config(1,(uint8_t*) &power_analog_5000,sizeof(power_rail_cfg_t));
     pwr_rail_store_config(2,(uint8_t*) &power_analog_1200,sizeof(power_rail_cfg_t));
     pwr_rail_store_config(3,(uint8_t*) &power_digital_2400,sizeof(power_rail_cfg_t));
     pwr_rail_store_config(4,(uint8_t*) &power_digital_OFFLINE,sizeof(power_rail_cfg_t));
    for(int i=5;i<PWR_MAX_RAILS;i++)
    {
         pwr_rail_store_config(i,(uint8_t*)&power_digital_OFFLINE,sizeof(power_rail_cfg_t));
    }
    pwr_seq_store_config((uint8_t *)&power_controller_basic,sizeof(power_controller_cfg_t));
//@     pwr_seq_store_map((uint8_t *)&power_rail_maps,sizeof(power_rail_maps)); //@@@ hard constant
    #endif
DROP0();
    pwr_seq_restore_all(); /* cfg_store --> cfg */
    pwr_seq_configure();   /* cfg used to configure the IO pins*/
    PowerController.ctrl->event = 0;
    PowerController.ctrl->rails_ready = 0;
    PowerController.ctrl->rails_enabled = 0;
    p_rail = PowerController.rails;
    for(int i=0;i<PWR_MAX_RAILS;i++) //@@@DWR code only handles one port at the moment
    {
        memset(p_rail->ctrl,0,sizeof(power_rail_ctrl_t));
        p_rail++;
    }
    PowerController.ctrl->state = PWR_SEQ_IDLE;
    POPB(); //@@@ turn on the blue led

    CP = CPAN_open(&control_panel_initial);  /* open the control panel */
    comm_init(PowerController.cfg->pmbus_address, app_sequencer_comm_cb, PowerController.GPIO->usage.SYSPINS.UART_TX);  /* open the comm bus */
    print_controller(4);
    return (CP == NULL) ? -1 : 0;
}
int app_func_startup (void)
{
    APP_INFO_PRINT("\nSEQUENCER STARTUP\n");
/*  SW1 starts the sequencer */    
POP0();
#if 1 //@@DEBUG
    R_ICU_ExternalIrqOpen(&g_SW1_ctrl, &g_SW1_cfg);
    R_ICU_ExternalIrqEnable(&g_SW1_ctrl);    
#endif    
    if (PowerController.ctrl->master_controller)
    {
        R_GPT_Open  (&g_T0_ctrl, &g_T0_cfg);
        R_GPT_Enable(&g_T0_ctrl);
        R_GPT_Start (&g_T0_ctrl);
    }  
    else
    {
        R_ICU_ExternalIrqOpen(&g_SYNC_irq_ctrl, &g_SYNC_irq_cfg);
        R_ICU_ExternalIrqEnable(&g_SYNC_irq_ctrl);
    }
    DROP0();
    
    return 0;
}

int app_func_restart (void)
{
    return 0;
}
/*

    The GPIO->pin[] are pointers to the pin's PFS register.  These set in the initial condition 

*/

int app_func_run     (void)
{
   bool loop_again = false;
#if (0 == APP_PROCESSING)
    while(0 == (PowerController.ctrl->event & PWR_FLAG_POLL))
    {
    /** WFI **/
    }       
#endif   
   PowerController.ctrl->event &= (uint32_t) ~PWR_FLAG_POLL;
   if (PowerController.ctrl->event & PWR_FLAG_SERVICE)
   {
        if (0 == comm_service())
        {
            PowerController.ctrl->event &= (uint32_t) ~PWR_FLAG_SERVICE;
        }
   }
   switch(PowerController.ctrl->state)
   {    
        case PWR_SEQ_RESET:
            // Fall through to IDLE case
        case PWR_SEQ_IDLE:
            if (PowerController.ctrl->event & PWR_FLAG_ENABLE)
            {
                PowerController.ctrl->state = PWR_SEQ_RUN;
                PowerController.ctrl->rails_enabled = 0;
                DROPB();
            }
            break;
        case PWR_SEQ_RUN:
            loop_again = false;
            do {
            for(int i=0;i<PWR_MAX_RAILS;i++)
            {
                uint32_t GPI      = PowerController.ctrl->GPI;
                uint32_t Page     = PowerController.ctrl->Page;
                uint32_t GPI_on   = PowerController.rails[i].cfg->SEQ_config.GPI_seq_mask_on;
                uint32_t GPI_off  = PowerController.rails[i].cfg->SEQ_config.GPI_seq_mask_off;
                uint32_t Page_on  = PowerController.rails[i].cfg->SEQ_config.page_seq_on_dep_msk;
                uint32_t Page_off = PowerController.rails[i].cfg->SEQ_config.page_seq_off_dep_msk;
                uint8_t ID        = PowerController.rails[i].cfg->SEQ_config.ID;
                uint8_t conf      = PowerController.rails[i].cfg->SEQ_config.ID_other;
                power_rail_t *rail = &PowerController.rails[i];
                switch (PowerController.rails[i].ctrl->state) {
                    case PWR_RAIL_OFF:
                         if ( ((GPI & GPI_on) == GPI_on  ) && ((Page & Page_on) == Page_on) )
                         {
                             PowerController.rails[i].ctrl->state = PWR_RAIL_ON;
                             rail->ctrl->state = PWR_RAIL_ON;
                             PowerController.rails[i].ctrl->en_out = 1; //@@@ TIMER BABY
                         }
                         break;
                    case PWR_RAIL_ON:
                         if ( ((GPI & GPI_off) == GPI_off  ) && ((Page & Page_off) == Page_off) )
                         {
                             PowerController.rails[i].ctrl->state = PWR_RAIL_OFF; //@@@ not taking into account delays yet
                             PowerController.rails[i].ctrl->dis_out = 1; //@@@ TIMER BABY
                         }
                         break;
                    default: break;
                }
                if (PowerController.rails[i].ctrl->en_out)
                {
                    PowerController.ctrl->Page |= (1 << i);  /* lets everybody know you're enabled */
                    PowerController.rails[i].ctrl->en_out = 0;
                    if (ID > 0)
                    {
                        switch(conf) {
                            /* Active low */
                            case (2): /* Active */
                            case (3): /* open drain */
                               PWR_PIN_ASSERT_LOW(ID-1);
//                               *((uint32_t*) PowerController.GPIO->pin[ID-1]) |= (uint32_t)  0x00000004;  /* Set PDR bit */
//                               *((uint32_t*) PowerController.GPIO->pin[ID-1]) &= (uint32_t) ~0x00000001;  /* clear PODR bit */
                               break;
                            /* Active High */
                            case (6):
                                PWR_PIN_ASSERT_HI(ID-1);
//                               *((uint32_t*) PowerController.GPIO->pin[ID-1]) |= (uint32_t)  0x00000004;  /* Set PDR bit */
//                               *((uint32_t*) PowerController.GPIO->pin[ID-1]) |= (uint32_t) ~0x00000001;  /* clear PODR bit */
                               break;
                            case (7):
                                PWR_PIN_ASSERT_OPEN(ID-1);
//                               *((uint32_t*) PowerController.GPIO->pin[ID-1]) |= (uint32_t)  ~0x00000004;  /* Clr PDR bit (make it an input)*/
                               //@@@ what to do about the pullup resistor???
                               break;
                        }
                    }
                }
                if (PowerController.rails[i].ctrl->dis_out)
                {
                    PowerController.ctrl->Page &= (uint32_t) ~(1 << i);  /* lets everybody know you're not enabled */
                    PowerController.rails[i].ctrl->dis_out = 0;
                    if (ID > 0)
                    {
                        switch(conf) {
                            /* Active low */
                            case (2): /* Active */
                               PWR_PIN_ASSERT_HI(ID-1);
                               break;
                            case (3): /* open drain */
                               PWR_PIN_ASSERT_OPEN(ID-1);
                               break;
                            /* Active High */
                            case (6):
                                PWR_PIN_ASSERT_HI(ID-1);
                               break;
                            case (7):
                                PWR_PIN_ASSERT_LOW(ID-1);
                               //@@@ what to do about the pullup resistor???
                               break;
                        }
                    }
                }
                if (PowerController.rails[i].ctrl->en_out || PowerController.rails[i].ctrl->dis_out)
                {
                    PowerController.rails[i].ctrl->en_out = 0;
                    PowerController.rails[i].ctrl->dis_out = 0;
                    loop_again = true;
                }
            }
        }        while(loop_again);

            break;
        case PWR_SEQ_SEQUENCING_DOWN:
            break;
        case PWR_SEQ_FAULT_SHUTDOWN:
            break;
            default: break;
    }
    return 0;
}

/* 
     If this is the only controller, or the "master" controller, then this interrupt toggles the SYNC_CLK pin
     and then calls SYNC_cb.  If this is a slave, then SYNC_cb is called from the pin interrupt.
*/
volatile uint32_t rPFS; //@@DBG
volatile uint32_t *pPFS; //@@DBG
void T0_cb(timer_callback_args_t *p_args)
{
    uint32_t *p = (uint32_t*) PowerController.GPIO->usage.SYSPINS.SYNC_CLK;
    external_irq_callback_args_t *p_args2 = (external_irq_callback_args_t *) p_args->p_context;
    rPFS = *p; //@@DBG
    if (*p & 0x00000002)
    {
        *p &= (uint32_t) ~0x00000005;
    }
    else
    {
        *p |= (uint32_t) 0x00000001;
    }
    SYNC_cb(p_args2);
}

/* Callback function */
void SW1_cb(external_irq_callback_args_t *p_args) /* SW1 toggles the configured DBGPINS->START*/
{
    /* TODO: add your own code here */
    FSP_PARAMETER_NOT_USED(p_args);
    pPFS = ((uint32_t*) PowerController.GPIO->usage.DBGPINS.START);
    *pPFS ^= (uint32_t) 0x00000001;
}
void SYNC_cb(external_irq_callback_args_t *p_args)
{
    /* TODO: add your own code here */
    FSP_PARAMETER_NOT_USED(p_args);
    pwr_mod_poll((uint16_t*) &ControlPanel.adc_value[0]); /* poll the ADC and update monitor_mv for each rail */
    pwr_seq_poll_GPI();
    pwr_seq_poll_Page();
#if APP_PROCESSING
    app_event_flag_seti(SYSFLG_PWR_FLAG_POLL,0);
#endif
    PowerController.ctrl->event |= PWR_FLAG_POLL; 
}
void app_sequencer_comm_cb(comm_event_t event, void *ctx)
{
    FSP_PARAMETER_NOT_USED(ctx);
    switch (event)
    {
    case COMM_EVENT_EOP:
#if APP_PROCESSING    /* tell the APP layer */
        app_event_flag_seti(SYSFLG_PWR_FLAG_SERVICE, 0); /* this signals the main loop to service the read (transmitting data for us)*/
#endif        
        PowerController.ctrl->event |= PWR_FLAG_SERVICE; /* tell the app_sequencer layer*/
        break;
    case COMM_EVENT_ERROR:
//        app_event_flag_seti(SYSFLG_PWR_PMBUS_ERROR, 0); /* this signals the main loop to service the read (transmitting data for us)*/
        break;
    default:
        break;
    }
}
/*
     PFS registers:
     BASE ADDRESS: 0x4008_0800
          INDEX:   0x       40
     for(m=0;i<NUMBER_OF_PORTS)    
       for(n=0)
          address = BASE_ADDRESS + (0x40 * m) + (0x04 * n)
*/