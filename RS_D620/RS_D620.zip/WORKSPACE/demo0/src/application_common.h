#ifndef APPLICATION_COMMON_H_
#define APPLICATION_COMMON_H_

#include <stdint.h>
#include "bsp_api.h"  // IWYU pragma: keep (provides BSP types/macros for downstream includers)




#define APP_HAS_DEBUG_IO     (1)  /* adds the ability to POP, DROP and TOG gpio pins for logic analyzer debugging */
#define APP_HAS_CONTROLPANEL (1)  /* adds a control panel for runtime manipulation of components */
#define APP_HAS_CONSOLE      (1)  /* adds a console to support prints to UART and input command parsing */
#define APP_HAS_CMD_SHELL    (0)  /* adds a command shell to support runtime commands */
#define APP_PROCESSING       (1)  /* adds a processing loop to support runtime processing of events */

#if APP_HAS_CONSOLE
#include "console/console_port.h" //IWYU pragma: keep
#if APP_HAS_CMD_SHELL
#include "commands/commands.h"
#endif
#define APP_ASSERT(_a_,_b_,_c_) if(_a_) {console_Print(_b_); console_Print("\n");} else {console_Print(_c_); console_Print("\n"); assert(false);}
#define APP_INFO_PRINT(_a_) console_Print(_a_)
#define APP_ERR_PRINT(_a_) { console_SetColor(CONSOLE_COLOR_RED); console_Print(_a_); console_SetColor(CONSOLE_COLOR_NORMAL); }
#define APP_PRINT(_a_) console_Print(_a_) /* blocking print of a single null-terminated string */
#else /*  APP does not have a console */
#define APP_ASSERT(_a_,_b_,_c_) assert(_a_)
#define APP_INFO_PRINT(_a_)
#define APP_ERR_PRINT(_a_)
#define APP_PRINT(_a_)
#endif


/* BUILD MODULE OPTIONS */
//-->#define APPCFG_BUILD_xxx       (1)

/* BUILD CONFIGURATION OPTIONS */
#define APPCFG_RTOS_NONE     (0)
#define APPCFG_RTOS_AZURE    (1)
#define APPCFG_RTOS_FREERTOS (2)
#define APPCFG_RTOS_ZEPHYR   (3)
#define APPCFG_RTOS          ( BSP_CFG_RTOS)
#if   (APPCFG_RTOS == APPCFG_RTOS_NONE) /* Bare METAL */
#include "hal_data.h"  // IWYU pragma: keep (provides bsp_leds_t etc. for downstream includers)
#elif (APPCFG_RTOS == APPCFG_RTOS_AZURE) /* Azure */
#include "app_thread.h"
#elif (APPCFG_RTOS == APPCFG_RTOS_FREERTOS) /* Fee RTOS */
#include "app_thread.h"
#elif (APPCFG_RTOS == APPCFG_RTOS_ZEPHYR) /* Zephyr */
#include "app_thread.h"
#endif
//-->#define APPCFG_xxx

/* ATTRIBUTES  */
//-->#define APPCFG_ATTRIB_xxx                BSP_ALIGN_VARIABLE(16) BSP_PLACE_IN_SECTION(".sdram")         

/* define attributes of the system */
//-->#define APPCFG_USB_IDLE_SLEEP  (100)  /* how many ticks to sleep whilst waiting to be told to start or check for detach */

/*  SYSTEM FLAG DEFINITIONS */
#define SYSFLG_APP_RESTART       (0x00000001)
#if APP_HAS_CONSOLE
#define SYSFLG_CONSOLE_DATA      (0x00000002)
#endif
#define SYSFLG_PWR_FLAG_POLL     (0x00000004)
#define SYSFLG_DATAFLASH_READY   (0x00000008)
#define SYSFLG_PWR_READBACK      (0x00000010)
#define SYSFLG_PWR_FLAG_SERVICE  (0x00000020)
//-->#define SYSFLG_xxx    (0x00000004)

#define DF_POWER_BASE_ADDR        (BSP_FEATURE_FLASH_DATA_FLASH_START)
//#define DF_POWER_PINMAP_SIZE      (0x80)  /* needs 128 bytes, 32 rails each having 4 bytes */
//#define DF_POWER_FLTMAP_SIZE      (0x80)  /* needs 57 bytes */
#define DF_POWER_CONFIG_SIZE      (0x400)
#define DF_POWER_RAIL_RECORD_SIZE (0xC0)
#define DF_POWER_LARGEST_SIZE     (DF_POWER_CONFIG_SIZE) /* choose largest consumer */

#define DF_SEQUENCER_CONFIG_ADDR  (DF_POWER_BASE_ADDR)  /* dataflash address for the power sequencer configuration */
//#define DF_MONITOR_CONFIG_ADDR    ()
//#define DF_POWER_RAIL_PINMAP_ADDR (DF_SEQUENCER_CONFIG_ADDR  + DF_POWER_CONFIG_SIZE)
//#define DF_POWER_RAIL_FLTMAP_ADDR (DF_POWER_RAIL_PINMAP_ADDR + DF_POWER_PINMAP_SIZE)
#define DF_POWER_RAIL_CONFIG_ADDR (DF_SEQUENCER_CONFIG_ADDR  + DF_POWER_CONFIG_SIZE)  /* dataflash address for the power rail configurations */

/* PMBUS stuff */
#define APP_PMBUS_PFS_SDA 0x07010400  //@@@ this might not be right and won't get tested until PMbus integration
#define APP_PMBUS_PFS_SCL 0x07010400

/* APPLICATION STATE MACHINE */
typedef enum app_state_e {
    APP_STATE_RESET,
    APP_STATE_STARTUP,
    APP_STATE_RUNNING,
    APP_STATE_RESTART,
    APP_STATE_ERROR,
    APP_STATE_SLEEP
    /*USER*/
} app_state_t;
typedef enum app_flag_ctl_e {
    APP_FLAG_OR,
    APP_FLAG_OR_CLEAR,
    APP_FLAG_AND,
    APP_FLAG_AND_CLEAR
}app_flag_ctl_t;

#if APP_HAS_CMD_SHELL
typedef struct lookup_s {
    uint32_t val;
    char* str;
} lookup_t;
#endif


#if APP_HAS_CONTROLPANEL
#define CPAN_POLL { if (ControlPanel.stat & CPAN_STAT_UPDATE) CPAN_update();}
#else
#define CPAN_POLL { }
#endif

/* application context */
typedef struct s_app {
    app_state_t state;
#if   (APPCFG_RTOS == APPCFG_RTOS_NONE) /* Bare METAL */
    uint32_t events;
#elif (APPCFG_RTOS  == APPCFG_RTOS_AZURE) /* Azure */
    TX_EVENT_FLAGS_GROUP events;
#elif (APPCFG_RTOS == APPCFG_RTOS_FREERTOS) /* Fee RTOS */
#error needs implementing
#elif (APPCFG_RTOS == APPCFG_RTOS_ZEPHYR) /* Zephyr */
#error needs implementing
#endif
   /* USER FIELDS */
} app_t;
extern app_t App;

#if APP_HAS_DEBUG_IO
#include "POP/pop.h" // IWYU pragma: keep
#endif
/* PUBLISHED functions */
int app_event_flag_get(uint32_t msk,app_flag_ctl_t ctl, uint32_t timeout,uint32_t *flgs);
int app_event_flag_set(uint32_t,uint32_t*);
int app_event_flag_clr(uint32_t,uint32_t*);
int app_event_flag_geti(uint32_t,bool,uint32_t,uint32_t*);
int app_event_flag_seti(uint32_t,uint32_t*);
int app_event_flag_clri(uint32_t,uint32_t*);
void app_delay_ms(uint32_t);

#endif /* APPLICATION_COMMON_H_ */










/*
 *    Some notes about some stuff:
 *
 *    To put the stack into DTCM, add a section in the Linker sections tab:
 *    *(.bss_g_main_stack)   DTCM Uninitialized
 *    *(,stack,new_thread0)  DTCM Zeroed
 *
 *    Then, OFS1_SEC  Enable,
 *    Tightly Coupled Memory (TCM)/Cache ECC      Disable ECC for TCM and Cache
 *
 *    To add the DMA to the USB stack:
 *    USB properties DMA/DTC support =  Enabled
 *    add the DMA element on the left
 *    transfer size = 4-bytes,
 *    Activation source = USBHS FIFO 1 (DMA transfer request 1)
 *    DMA on the right
 *    transfer size = 4 bytes
 *
 *    Priority 0 (Highest)   <--- Can PREEMPT this thread
      ...
Priority 14            <--- Can PREEMPT this thread
----------------------- PREEMPTION THRESHOLD (Set to 15)
Priority 15            <--- BLOCKED from preempting
      ...
Priority 19            <--- BLOCKED from preempting
Priority 20 (Actual)   <--- CURRENT RUNNING THREAD
Priority 21+ (Lowest)  <--- Cannot run anyway
 *
 *
 *
 *
 *
 *
 *
 *
 */
